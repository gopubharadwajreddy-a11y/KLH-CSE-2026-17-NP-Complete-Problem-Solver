ALGOMASTER - JAVA DSA PROJECT
=============================

The project includes:
- String Matching
- Dynamic Programming
- Network Flow and Matching
- CSV Dataset Testing

Run:
    cd src
    javac AlgoMaster.java
    java AlgoMaster

Choose option 5 to test the CSV datasets.

Dataset files are stored in:
    data/

Available datasets:
- string_matching_dataset.csv
- dynamic_programming_dataset.csv
- network_flow_dataset.csv
- bipartite_matching_dataset.csv
