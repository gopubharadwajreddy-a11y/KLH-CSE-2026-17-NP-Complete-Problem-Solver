import java.util.*;
import java.io.*;

public class AlgoMaster {

    // ---------------- String Matching ----------------

    static List<Integer> kmp(String text, String pattern) {
        List<Integer> result = new ArrayList<>();
        if (pattern.length() == 0) return result;

        int[] lps = buildLPS(pattern);
        int i = 0, j = 0;

        while (i < text.length()) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++;
                j++;
            }

            if (j == pattern.length()) {
                result.add(i - j);
                j = lps[j - 1];
            } else if (i < text.length() && text.charAt(i) != pattern.charAt(j)) {
                if (j > 0) j = lps[j - 1];
                else i++;
            }
        }
        return result;
    }

    static int[] buildLPS(String pattern) {
        int[] lps = new int[pattern.length()];
        int len = 0;

        for (int i = 1; i < pattern.length();) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                lps[i++] = ++len;
            } else if (len > 0) {
                len = lps[len - 1];
            } else {
                lps[i++] = 0;
            }
        }
        return lps;
    }

    static int[] zArray(String s) {
        int[] z = new int[s.length()];
        int left = 0, right = 0;

        for (int i = 1; i < s.length(); i++) {
            if (i <= right) z[i] = Math.min(right - i + 1, z[i - left]);

            while (i + z[i] < s.length() &&
                    s.charAt(z[i]) == s.charAt(i + z[i])) {
                z[i]++;
            }

            if (i + z[i] - 1 > right) {
                left = i;
                right = i + z[i] - 1;
            }
        }
        return z;
    }

    static List<Integer> zSearch(String text, String pattern) {
        List<Integer> result = new ArrayList<>();
        if (pattern.length() == 0) return result;

        String combined = pattern + "$" + text;
        int[] z = zArray(combined);

        for (int i = pattern.length() + 1; i < combined.length(); i++) {
            if (z[i] == pattern.length()) {
                result.add(i - pattern.length() - 1);
            }
        }
        return result;
    }

    static List<Integer> rabinKarp(String text, String pattern) {
        List<Integer> result = new ArrayList<>();
        int n = text.length();
        int m = pattern.length();

        if (m == 0 || m > n) return result;

        long mod = 1_000_000_007L;
        long base = 257L;
        long patternHash = 0;
        long windowHash = 0;
        long power = 1;

        for (int i = 0; i < m; i++) {
            patternHash = (patternHash * base + pattern.charAt(i)) % mod;
            windowHash = (windowHash * base + text.charAt(i)) % mod;
            if (i < m - 1) power = (power * base) % mod;
        }

        for (int i = 0; i <= n - m; i++) {
            if (patternHash == windowHash && text.regionMatches(i, pattern, 0, m)) {
                result.add(i);
            }

            if (i < n - m) {
                windowHash = (windowHash - text.charAt(i) * power) % mod;
                if (windowHash < 0) windowHash += mod;
                windowHash = (windowHash * base + text.charAt(i + m)) % mod;
            }
        }
        return result;
    }

    // ---------------- Dynamic Programming ----------------

    static int levenshtein(String a, String b) {
        int[][] dp = new int[a.length() + 1][b.length() + 1];

        for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.length(); j++) dp[0][j] = j;

        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                dp[i][j] = Math.min(
                        Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost
                );
            }
        }
        return dp[a.length()][b.length()];
    }

    static int matrixChain(int[] dimensions) {
        int n = dimensions.length - 1;
        int[][] dp = new int[n][n];

        for (int length = 2; length <= n; length++) {
            for (int i = 0; i <= n - length; i++) {
                int j = i + length - 1;
                dp[i][j] = Integer.MAX_VALUE;

                for (int k = i; k < j; k++) {
                    long cost = (long) dp[i][k]
                            + dp[k + 1][j]
                            + (long) dimensions[i] * dimensions[k + 1] * dimensions[j + 1];
                    dp[i][j] = (int) Math.min(dp[i][j], cost);
                }
            }
        }
        return dp[0][n - 1];
    }

    static int tspBitmask(int[][] distance) {
        int n = distance.length;
        int totalMasks = 1 << n;
        int inf = 1_000_000_000;
        int[][] dp = new int[totalMasks][n];

        for (int[] row : dp) Arrays.fill(row, inf);
        dp[1][0] = 0;

        for (int mask = 1; mask < totalMasks; mask++) {
            for (int u = 0; u < n; u++) {
                if ((mask & (1 << u)) == 0 || dp[mask][u] == inf) continue;

                for (int v = 0; v < n; v++) {
                    if ((mask & (1 << v)) != 0) continue;
                    int nextMask = mask | (1 << v);
                    dp[nextMask][v] = Math.min(
                            dp[nextMask][v],
                            dp[mask][u] + distance[u][v]
                    );
                }
            }
        }

        int answer = inf;
        int fullMask = totalMasks - 1;
        for (int i = 1; i < n; i++) {
            answer = Math.min(answer, dp[fullMask][i] + distance[i][0]);
        }
        return answer;
    }

    // ---------------- Network Flow ----------------

    static int edmondsKarp(int[][] capacity, int source, int sink) {
        int n = capacity.length;
        int[][] residual = new int[n][n];

        for (int i = 0; i < n; i++) {
            residual[i] = capacity[i].clone();
        }

        int maxFlow = 0;

        while (true) {
            int[] parent = new int[n];
            Arrays.fill(parent, -1);
            parent[source] = source;

            Queue<Integer> queue = new ArrayDeque<>();
            queue.add(source);

            while (!queue.isEmpty() && parent[sink] == -1) {
                int u = queue.poll();

                for (int v = 0; v < n; v++) {
                    if (parent[v] == -1 && residual[u][v] > 0) {
                        parent[v] = u;
                        queue.add(v);
                        if (v == sink) break;
                    }
                }
            }

            if (parent[sink] == -1) break;

            int pathFlow = Integer.MAX_VALUE;
            for (int v = sink; v != source; v = parent[v]) {
                pathFlow = Math.min(pathFlow, residual[parent[v]][v]);
            }

            for (int v = sink; v != source; v = parent[v]) {
                int u = parent[v];
                residual[u][v] -= pathFlow;
                residual[v][u] += pathFlow;
            }

            maxFlow += pathFlow;
        }
        return maxFlow;
    }

    static List<Integer> minCutSourceSide(int[][] capacity, int source, int sink) {
        int n = capacity.length;
        int[][] residual = new int[n][n];

        for (int i = 0; i < n; i++) residual[i] = capacity[i].clone();

        while (true) {
            int[] parent = new int[n];
            Arrays.fill(parent, -1);
            parent[source] = source;

            Queue<Integer> queue = new ArrayDeque<>();
            queue.add(source);

            while (!queue.isEmpty() && parent[sink] == -1) {
                int u = queue.poll();
                for (int v = 0; v < n; v++) {
                    if (parent[v] == -1 && residual[u][v] > 0) {
                        parent[v] = u;
                        queue.add(v);
                    }
                }
            }

            if (parent[sink] == -1) break;

            int flow = Integer.MAX_VALUE;
            for (int v = sink; v != source; v = parent[v]) {
                flow = Math.min(flow, residual[parent[v]][v]);
            }

            for (int v = sink; v != source; v = parent[v]) {
                int u = parent[v];
                residual[u][v] -= flow;
                residual[v][u] += flow;
            }
        }

        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new ArrayDeque<>();
        queue.add(source);
        visited[source] = true;

        while (!queue.isEmpty()) {
            int u = queue.poll();
            for (int v = 0; v < n; v++) {
                if (!visited[v] && residual[u][v] > 0) {
                    visited[v] = true;
                    queue.add(v);
                }
            }
        }

        List<Integer> side = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (visited[i]) side.add(i);
        }
        return side;
    }

    static int maxBipartiteMatching(int left, int right, int[][] edges) {
        int source = 0;
        int leftStart = 1;
        int rightStart = leftStart + left;
        int sink = rightStart + right;
        int n = sink + 1;

        int[][] capacity = new int[n][n];

        for (int i = 0; i < left; i++) capacity[source][leftStart + i] = 1;
        for (int i = 0; i < right; i++) capacity[rightStart + i][sink] = 1;

        for (int[] edge : edges) {
            capacity[leftStart + edge[0]][rightStart + edge[1]] = 1;
        }

        return edmondsKarp(capacity, source, sink);
    }


    // ---------------- Dataset Support ----------------

    static List<String> parseCSVLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (ch == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    quoted = !quoted;
                }
            } else if (ch == ',' && !quoted) {
                fields.add(current.toString());
                current.setLength(0);
            } else {
                current.append(ch);
            }
        }

        fields.add(current.toString());
        return fields;
    }

    static List<List<String>> readCSV(String fileName) {
        List<List<String>> rows = new ArrayList<>();
        File file = new File("data" + File.separator + fileName);

        if (!file.exists()) {
            System.out.println("Dataset not found: " + file.getPath());
            System.out.println("Make sure you run the program from the project folder.");
            return rows;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    rows.add(parseCSVLine(line));
                }
            }
        } catch (IOException e) {
            System.out.println("Could not read dataset: " + e.getMessage());
        }

        return rows;
    }

    static void datasetMenu(Scanner sc) {
        while (true) {
            System.out.println("\n--- DATASET TESTING ---");
            System.out.println("1. String Matching Dataset");
            System.out.println("2. Dynamic Programming Dataset");
            System.out.println("3. Network Flow Dataset");
            System.out.println("4. Bipartite Matching Dataset");
            System.out.println("0. Back");
            System.out.print("Choose dataset: ");

            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1":
                    runStringDataset();
                    break;
                case "2":
                    runDPDataset();
                    break;
                case "3":
                    runFlowDataset();
                    break;
                case "4":
                    runMatchingDataset();
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    static void runStringDataset() {
        List<List<String>> rows = readCSV("string_matching_dataset.csv");
        if (rows.size() <= 1) return;

        System.out.println("\nString Matching Dataset Results");
        System.out.println("--------------------------------");

        for (int r = 1; r < rows.size(); r++) {
            List<String> row = rows.get(r);
            String id = row.get(0);
            String text = row.get(1);
            String pattern = row.get(2);
            String algorithm = row.get(3);

            List<Integer> result;
            if (algorithm.equalsIgnoreCase("KMP")) {
                result = kmp(text, pattern);
            } else if (algorithm.equalsIgnoreCase("Z")) {
                result = zSearch(text, pattern);
            } else {
                result = rabinKarp(text, pattern);
            }

            System.out.println(id + " | " + algorithm +
                    " | pattern = " + pattern +
                    " | positions = " + result);
        }
    }

    static void runDPDataset() {
        List<List<String>> rows = readCSV("dynamic_programming_dataset.csv");
        if (rows.size() <= 1) return;

        System.out.println("\nDynamic Programming Dataset Results");
        System.out.println("-----------------------------------");

        for (int r = 1; r < rows.size(); r++) {
            List<String> row = rows.get(r);
            String id = row.get(0);
            String type = row.get(1);
            String input = row.get(2);

            if (type.equalsIgnoreCase("Levenshtein")) {
                String target = row.get(3);
                int result = levenshtein(input, target);
                System.out.println(id + " | Levenshtein | " + input +
                        " -> " + target + " | result = " + result);

            } else if (type.equalsIgnoreCase("MatrixChain")) {
                String[] parts = input.split(",");
                int[] dims = new int[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    dims[i] = Integer.parseInt(parts[i].trim());
                }
                int result = matrixChain(dims);
                System.out.println(id + " | Matrix Chain | result = " + result);

            } else if (type.equalsIgnoreCase("TSP")) {
                String[] graphRows = input.split("\\|");
                int n = graphRows.length;
                int[][] distance = new int[n][n];

                for (int i = 0; i < n; i++) {
                    String[] values = graphRows[i].split(",");
                    for (int j = 0; j < n; j++) {
                        distance[i][j] = Integer.parseInt(values[j].trim());
                    }
                }

                int result = tspBitmask(distance);
                System.out.println(id + " | TSP | result = " + result);
            }
        }
    }

    static int[][] parseFlowEdges(int vertices, String edgesText) {
        int[][] capacity = new int[vertices][vertices];
        String[] edges = edgesText.split(";");

        for (String edge : edges) {
            String[] parts = edge.split(":");
            String[] nodes = parts[0].split("-");
            int from = Integer.parseInt(nodes[0]);
            int to = Integer.parseInt(nodes[1]);
            int cap = Integer.parseInt(parts[1]);
            capacity[from][to] = cap;
        }

        return capacity;
    }

    static void runFlowDataset() {
        List<List<String>> rows = readCSV("network_flow_dataset.csv");
        if (rows.size() <= 1) return;

        System.out.println("\nNetwork Flow Dataset Results");
        System.out.println("----------------------------");

        for (int r = 1; r < rows.size(); r++) {
            List<String> row = rows.get(r);

            String id = row.get(0);
            int vertices = Integer.parseInt(row.get(1));
            int source = Integer.parseInt(row.get(3));
            int sink = Integer.parseInt(row.get(4));
            int[][] capacity = parseFlowEdges(vertices, row.get(2));

            int result = edmondsKarp(capacity, source, sink);
            System.out.println(id + " | Max Flow = " + result +
                    " | Source = " + source + " | Sink = " + sink);
        }
    }

    static int indexOf(String[] values, String target) {
        for (int i = 0; i < values.length; i++) {
            if (values[i].trim().equals(target.trim())) return i;
        }
        return -1;
    }

    static void runMatchingDataset() {
        List<List<String>> rows = readCSV("bipartite_matching_dataset.csv");
        if (rows.size() <= 1) return;

        System.out.println("\nBipartite Matching Dataset Results");
        System.out.println("----------------------------------");

        for (int r = 1; r < rows.size(); r++) {
            List<String> row = rows.get(r);

            String id = row.get(0);
            String[] leftNodes = row.get(1).split(",");
            String[] rightNodes = row.get(2).split(",");

            String[] edgeList = row.get(3).split(";");
            int[][] edges = new int[edgeList.length][2];

            for (int i = 0; i < edgeList.length; i++) {
                String[] parts = edgeList[i].split("-");
                edges[i][0] = indexOf(leftNodes, parts[0]);
                edges[i][1] = indexOf(rightNodes, parts[1]);
            }

            int result = maxBipartiteMatching(leftNodes.length, rightNodes.length, edges);
            System.out.println(id + " | Maximum Matching = " + result);
        }
    }

    // ---------------- Program Menus ----------------

    static void showAlgorithmGuide() {
        System.out.println("\n--- ALGORITHM GUIDE ---");
        System.out.println("Pattern matching       : KMP, Z Algorithm, Rabin-Karp");
        System.out.println("String transformation  : Dynamic Programming");
        System.out.println("Subset optimization    : Bitmask DP");
        System.out.println("Capacity / matching    : Network Flow");
        System.out.println("\nChoose an algorithm based on the structure of the problem.");
    }

    static void stringMatchingMenu(Scanner sc) {
        System.out.println("\n--- STRING MATCHING ---");
        System.out.print("Enter text: ");
        sc.nextLine();
        String text = sc.nextLine();
        System.out.print("Enter pattern: ");
        String pattern = sc.nextLine();

        System.out.println("\nKMP         : " + kmp(text, pattern));
        System.out.println("Z Algorithm : " + zSearch(text, pattern));
        System.out.println("Rabin-Karp  : " + rabinKarp(text, pattern));
    }

    static void dynamicProgrammingMenu() {
        System.out.println("\n--- DYNAMIC PROGRAMMING ---");
        System.out.println("1. String Edit Distance");
        System.out.println("2. Matrix Chain Multiplication");
        System.out.println("3. Travelling Salesman Problem");
        System.out.println("4. Show all sample results");
    }

    static void runDPSamples() {
        System.out.println("\nEdit Distance (kitten -> sitting) = " + levenshtein("kitten", "sitting"));
        System.out.println("Matrix Chain [10,20,30,40,30] = " +
                matrixChain(new int[]{10, 20, 30, 40, 30}));

        int[][] distance = {
                {0, 10, 15, 20},
                {10, 0, 35, 25},
                {15, 35, 0, 30},
                {20, 25, 30, 0}
        };
        System.out.println("TSP minimum tour cost = " + tspBitmask(distance));
    }

    static void flowMenu() {
        System.out.println("\n--- NETWORK FLOW & MATCHING ---");

        int[][] capacity = {
                {0, 16, 13, 0, 0, 0},
                {0, 0, 10, 12, 0, 0},
                {0, 4, 0, 0, 14, 0},
                {0, 0, 9, 0, 0, 20},
                {0, 0, 0, 7, 0, 4},
                {0, 0, 0, 0, 0, 0}
        };

        int flow = edmondsKarp(capacity, 0, 5);
        System.out.println("Maximum flow = " + flow);
        System.out.println("Source side of minimum cut = " + minCutSourceSide(capacity, 0, 5));

        int[][] matchingEdges = {
                {0, 0}, {0, 1}, {1, 0}, {2, 1}, {2, 2}
        };
        System.out.println("Maximum bipartite matching = " +
                maxBipartiteMatching(3, 3, matchingEdges));
    }

    static void runDemo() {
        System.out.println("\n========== SAMPLE DEMONSTRATION ==========");

        String text = "ABABDABACDABABCABABABABCABAB";
        String pattern = "ABABCABAB";
        System.out.println("\nString Matching");
        System.out.println("Text    : " + text);
        System.out.println("Pattern : " + pattern);
        System.out.println("KMP         : " + kmp(text, pattern));
        System.out.println("Z Algorithm : " + zSearch(text, pattern));
        System.out.println("Rabin-Karp  : " + rabinKarp(text, pattern));

        System.out.println("\nDynamic Programming");
        runDPSamples();

        System.out.println("\nNetwork Flow & Matching");
        flowMenu();

        System.out.println("\n===========================================");
        System.out.println("Demo completed successfully.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===============================================");
            System.out.println("       ALGOMASTER - ALGORITHM TOOLKIT");
            System.out.println("===============================================");
            System.out.println("1. String Matching");
            System.out.println("2. Dynamic Programming");
            System.out.println("3. Network Flow & Matching");
            System.out.println("4. Algorithm Guide");
            System.out.println("5. Test With Dataset");
            System.out.println("6. Run Sample Demonstration");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Please enter a number.");
                sc.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    stringMatchingMenu(sc);
                    break;
                case 2:
                    dynamicProgrammingMenu();
                    System.out.print("Choose an option (1-4): ");
                    int dpChoice = sc.nextInt();
                    if (dpChoice == 4) {
                        runDPSamples();
                    } else {
                        System.out.println("Sample result for this section:");
                        runDPSamples();
                    }
                    break;
                case 3:
                    flowMenu();
                    break;
                case 4:
                    showAlgorithmGuide();
                    break;
                case 5:
                    sc.nextLine();
                    datasetMenu(sc);
                    break;
                case 6:
                    runDemo();
                    break;
                case 0:
                    System.out.println("Thank you for using AlgoMaster.");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
